package parte2;
import java.util.ArrayList;
public class Roteador {
    private String nome;
    private ArrayList<Object> pacotesLST = new ArrayList<>(); 
    
    
    public Roteador(String nome){
      this.nome = nome;  
    }

    public void addPacote(Object pacote){
        //add to lst
        this.pacotesLST.add(pacote);
    }

    public boolean hasPacotes(){
        if (pacotesLST.isEmpty()==true){
            return false;
        }
        return true;
    }

    public void enviaPacote(){
        for(Object pacote : pacotesLST){
            System.out.println(pacote.toString());
            pacote.remove(pacote);
            //pacotesLST.remove(pacote);
        }
    }

    public void removePacote(Object pacot){
        int a = 0;
        for (Object pacote : pacotesLST){
            
            if (pacote == pacot) {
                //remove
                //pacotesLST.remove(pacot);
            }
            a++;
        }
    }

    @Override
    public String toString() {
        return "Roteador " + nome + ", pacotesLST=" + pacotesLST + "]";
    }

    
}

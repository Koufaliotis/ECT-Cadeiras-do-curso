package parte2;

public class Pacote {
    //????????what to do
    public Pacote(){
        
    }
}

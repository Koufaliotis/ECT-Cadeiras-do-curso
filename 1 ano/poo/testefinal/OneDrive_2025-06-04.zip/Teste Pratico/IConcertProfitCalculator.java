public interface IConcertProfitCalculator {
    public double calculateConcertProfit(Concert c);
}

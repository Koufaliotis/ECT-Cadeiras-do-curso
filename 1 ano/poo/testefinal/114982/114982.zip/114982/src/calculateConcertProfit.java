
public record calculateConcertProfit() {

}

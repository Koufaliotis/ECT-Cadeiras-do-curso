public interface ITransactionCostCalculator {
    public double calculateTransactionCost(Transaction t);
}

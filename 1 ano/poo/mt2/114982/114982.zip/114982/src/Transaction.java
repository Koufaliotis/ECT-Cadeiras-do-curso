
import java.time.LocalDateTime;

public class Transaction {
    private double horas;
    private String descrição;
    private String data; //<-----------------------------problem must be a class?

    
    public Transaction(String descrição,String data,double horas){
        //create class here no
        this.horas = horas;
        this.descrição = descrição;
        this.data = data;
    }

    public double getHoras() {
        return horas;
    }

    public String getDescrição() {
        return descrição;
    }

    public String getDate() {
        return data.toString();
    }

    public void setHoras(double horas) {
        this.horas = horas;
    }

    public void setDescrição(String descrição) {
        this.descrição = descrição;
    }

    public void setDate(String data) {//LocalDateTime
        this.data = data;
    }

    @Override
    public String toString() {
        return "Transaction [horas=" + horas + ", descrição=" + descrição + ", date=" + data + "]";
    }

    
}

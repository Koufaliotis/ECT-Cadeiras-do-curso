import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.io.File;
import java.time.temporal.Temporal;

public class TransactionManager {

    HashMap<Integer,Transaction> trasactionsLst = new HashMap<Integer,Transaction>(); 
    public TransactionManager(){

    }
    public void addTransaction(Transaction t){
        trasactionsLst.put(t.getID(), t);        
    }

    public void removeTransaction(int id){

        for(int keys : trasactionsLst.keySet()){
            if (keys == id) {
                trasactionsLst.remove(id);
                System.out.println("Transaction removed");
            }
        }

    }

    public String getTransaction(int id){

        for(int keys : trasactionsLst.keySet()){
            if (keys == id) {
                Transaction t = trasactionsLst.get(id);
                return t.toString();
            }
            
        }
        return "the trandaction doesnt exist";
    }

    public double calculateTransactionCost(int id){
        for(int keys : trasactionsLst.keySet()){
            if (keys == id) {
                Transaction t = trasactionsLst.get(id);
                StandardTransactionCostCalculator calculator = new StandardTransactionCostCalculator();
                double custo = calculator.calculateTransactionCost(t); //tem de ser aredondado
                return custo;
            }
            
        }
        return -1;
    }

    public void printAllTransactions(){
        Transaction t;
        for(int keys : trasactionsLst.keySet()){
            
            t = trasactionsLst.get(keys);
            System.out.println(t.toString());
        }
            
    }

    public void sortTransactionsByCost(){
            //sort by colllection first day then cost;
    }
    
    public void readFile(String file){
        File myFile = new File(file);
        String Line;
        String[] data;
        try (Scanner myReader = new Scanner(myFile)){
            while (myReader.hasNextLine()) {
                Line = myReader.nextLine();
                data= Line.split(";");
                Transaction t = new Transaction(data[2], data[3], Double.parseDouble(data[1]));
                addTransaction(null);
            }
            
        } catch (Exception e) {
            // TODO: handle exception
        }
    }

    public void writeFile(){
        //missing for now
    }
}

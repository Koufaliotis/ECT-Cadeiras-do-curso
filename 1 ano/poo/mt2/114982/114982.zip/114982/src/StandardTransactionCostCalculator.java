public class StandardTransactionCostCalculator extends ITransactionCostCalculator {

    public StandardTransactionCostCalculator(){}

    public double calculateTransactionCost(Transaction t){
        double custo;
        //costo
        if(diada semana ){//usar date
            custo = 50*t.getHoras();
            //desconto de quinta feira
            if (quinta) {
                custo = custo - custo*0.1;
                return custo;
            }
            return custo;
        }
        else{//fim de semana
            custo = 2*(50*t.getHoras());
            return custo;
        }
    }
}
